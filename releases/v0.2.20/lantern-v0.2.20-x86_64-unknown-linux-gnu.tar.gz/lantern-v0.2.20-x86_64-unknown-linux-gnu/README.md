Lantern - Peace Network Full Node (std-only)

Lantern is the full node implementation for the Peace Network.

It validates and syncs Peace chain state, runs the node P2P/RPC surfaces, and can optionally host TLS-backed list services for Weave and World Stage peers.

Build and run

Most operators should use Lantern in `lantern node ...` full-node mode. The list-service features are optional.

Express onboarding (end-user)

- Linux one-liner (recommended):
  - `curl -fsSL https://raw.githubusercontent.com/5310S/lantern/master/install.sh | sudo bash`
- Windows one-liner (PowerShell as Administrator):
  - `irm https://raw.githubusercontent.com/5310S/lantern/master/install.ps1 | iex`
  - Installer path: download and run `LanternSetup.exe` from the latest GitHub release.

Defaults:
- Chain: `peace-testnet`
- Bootstrap peer: `93.127.216.241:3000`

Advanced override (optional):
- Linux: `curl -fsSL https://raw.githubusercontent.com/5310S/lantern/master/install.sh | sudo bash -s -- --bootstrap 82.25.86.57:3000`
- Windows: `& ([scriptblock]::Create((irm https://raw.githubusercontent.com/5310S/lantern/master/install.ps1))) -Bootstrap "82.25.86.57:3000"`

Uninstall:
- Linux one-liner: `curl -fsSL https://raw.githubusercontent.com/5310S/lantern/master/uninstall.sh | sudo bash`
- Linux purge data: `curl -fsSL https://raw.githubusercontent.com/5310S/lantern/master/uninstall.sh | sudo bash -s -- --purge-data`
- Windows one-liner (PowerShell Admin): `irm https://raw.githubusercontent.com/5310S/lantern/master/uninstall.ps1 | iex`
- Windows purge data: `& ([scriptblock]::Create((irm https://raw.githubusercontent.com/5310S/lantern/master/uninstall.ps1))) -PurgeData`

Full onboarding docs: `docs/onboarding.md`

- Requires Rust (edition 2024-compatible toolchain). Minimal dependencies.
- Run with interactive setup: `lantern` (no args) and follow the menu
- Or: `cargo run` to start the interactive setup from source
- One‑button start: `lantern autostart` (or `cargo run -- autostart`)
  - Starts TLS per‑app listeners (9001/9002) + HTTP API with persistence.
  - Writes a Caddyfile in the current directory for `weave.5310s.com` and `worldstage.5310s.com`.
  - Enforces mTLS automatically if client CAs are present at `/etc/caddy/clients/{weave,worldstage}/ca.crt` (fallback to `$HOME/{weave,worldstage}.crt`).
  - Falls back to an HTTP Bearer token if CAs are missing; writes it to `./lantern_http_token` and injects it via Caddy `header_up`.
  - Attempts to run `caddy run --config ./Caddyfile`; if Caddy is missing, Lantern still runs and the Caddyfile is ready to use.
- One-click launchers:
  - macOS: double-click `packaging/lantern-launcher.command` (make executable) to open Terminal and run `lantern autostart`. Build the binary first (`cargo build --release`) or place `lantern` alongside the script.
  - Linux desktop: copy `packaging/lantern.desktop` to `~/.local/share/applications/` (or `/usr/share/applications`), ensure `lantern` is on PATH; it opens a terminal and runs `lantern autostart`.
- Override port: `PORT=9090 cargo run`
- Enable persistence: `DATA_DIR=data cargo run` (creates `data/` with `dating.txt` and `youtube.txt`)
- Enable Noise PSK: set `NOISE_PSK` to a 32-byte hex key (64 hex chars)
  - Example: `NOISE_PSK=0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef cargo run`
- Verify persisted staking params: `cargo run --bin restart_check -- ./data/chain` prints `chain_id`, `block_reward`, and `unbonding_period` from the sled store.

Peace chain defaults

- Chain IDs: `peace-testnet` (default) and `peace-mainnet`; addresses are Bech32 (`tpc`/`pc` hrp) over ed25519 pubkeys. All txs/blocks enforce the chain_id and address hrp.
- Limits: 1 MB block cap, 64 KB tx cap, 10s target spacing; canonical tx/block hashes use deterministic JSON (sign bytes omit signatures). Block headers carry an optional `miner` payout address.
- Economics: supply cap 21,000,000 with 1,000,000 to user + 5% treasury at genesis; block rewards start at 2 and halve every 6,307,200 blocks. Unbonding default: 60,480 blocks (~7 days). Rewards mint to the block miner when present; otherwise they route to the proposer payout with delegation/commission splits.
- Mining RPC: attestation tokens with capability `lantern-mining` are required (bearer or `attestation` param) and are filtered by the mobile allowlist (`MINING_MOBILE_ALLOWLIST` or `mobile-allowlist.{json,txt}`). `getMiningJob` returns chain_id/attestation_required plus proposer/payout; `submitShare/submitSolution` expect `{id, nonce, miner, session?, attestation}`, reject invalid miners/stale jobs, and pay block rewards to `miner`.
- Specs: `docs/peace-spec.md` (schema, canonical encodings, and test vectors). Deterministic bundles: `dist/peace-testnet.json` and `dist/peace-mainnet.json` (ports, bootstrap seeds, identity seed, `consensus_mode`, canonical genesis hash/state_root). Seed sled + node-config with `cargo run --bin init_peace_testnet -- --chain-id peace-<net> --bundle dist/peace-<net>.json --data-dir ./data/peace-<net> --user-addr <pc/tpc...>` (script helper: `scripts/init_peace_testnet.sh` for testnet). Addresses/chain IDs are validated, bootstrap ports are checked, and the init script derives `p2p_identity.json` deterministically unless an existing identity is preserved.
- Reference genesis anchors: testnet hash `09924b760df476b5299dad4fa99d65b58c330bc5200b37c1b421d883fddb4833`, root `31055a0674d994ef9eb88ee309809a3623fc236547987a5c7458829709a72bee`; mainnet hash `fe08540b59f196e17ae3edb945eb684ab0436bba77314b4b89b4f2ab0deba298`, root `a816a10134a5a85a4aa50fccc0e8a4d0556546205da718ea8b40ec912d0c0591`.

Testnet full node (release binary, quickest path)

1. Download and unpack the latest release for your OS/arch, then `cd` into that folder (it should contain `lantern` and `dist/peace-testnet.json`).
2. Initialize deterministic testnet chain state:
   - `./init_peace_testnet --chain-id peace-testnet --bundle ./dist/peace-testnet.json --data-dir ./data/peace-testnet --user-addr tpc1khsusq3p5e58gkc0u2n2g5zm9d7m2u328k667qvkq7hmkm2h0q9q5uhk7w`
3. Initialize node config as full node:
   - `./lantern node init --role full --data-dir ./data/peace-testnet --chain-id peace-testnet --p2p-port 3000 --rpc-port 8645 --bootstrap 93.127.216.241:3000`
4. Rotate identity (required; avoids deterministic node ID collisions):
   - `./lantern node rotate-identity --data-dir ./data/peace-testnet`
5. Start node with an admin bearer token for local health checks:
   - `export LANTERN_HTTP_TOKEN=testnet-local-admin`
   - `./lantern node run --data-dir ./data/peace-testnet`
6. In another terminal, verify health (authenticated):
   - `curl -ks -H "Authorization: Bearer $LANTERN_HTTP_TOKEN" https://127.0.0.1:8645/weave/chain/head`
7. Run preflight checks:
   - `chmod +x scripts/preflight_testnet.sh`
   - `LANTERN_BIN=./lantern ./scripts/preflight_testnet.sh ./data/peace-testnet peace-testnet`
   - Optional override: `LANTERN_BOOTSTRAP_HOST`/`LANTERN_BOOTSTRAP_PORT`.
8. Pre-flight check that bootstrap is reachable before starting:
   - `nc -z -v 93.127.216.241 3000` (optional)
   - If this fails, continue only if you are sure another bootstrap is configured in `node-config.json`.
9. Run all release gates in one shot:
   - `chmod +x scripts/release_gate_testnet.sh`
   - `./scripts/release_gate_testnet.sh`

Notes:
- Keep the terminal running while the node is online.
- If port `3000` or `8645` is in use, change both `--p2p-port` / `--rpc-port` in step 3.
- For internet-exposed RPC, put TLS/auth in front of the node (Caddy/Nginx) instead of opening it directly.

Security & PoW

- PoW is enforced by default; blocks must meet the advertised difficulty/target. Do **not** disable PoW in production.
- Genesis is anchored: the node verifies the height‑0 hash and state_root against the selected Peace bundle (mainnet or testnet). If you generate a custom genesis, distribute a matching bundle or the node will refuse to start.
- Binary trust is enforced on full peers: release upgrades must keep bootstrap hash allowlists in sync.
  - Check this binary hash: `./lantern node verify` (prints `binary_sha256=...`).
  - Release artifacts include `dist/BINARY_HASHES` from `scripts/release.sh`; use this hash in rollout planning.
  - During rolling upgrades, set `LANTERN_ALLOWED_HASHES=<old_hash>,<new_hash>` on bootstrap/full nodes before introducing new binaries.
- Mesh/peering: mesh handshake is **off by default** for zero‑config peering. To require the mesh handshake (shared secret), set `LANTERN_MESH_KEY=<hex-or-string>` on all peers.
- Unsafe overrides: only for testing, you can bypass PoW with `LANTERN_UNSAFE_ALLOW_SOFT_POW=1`. Production builds should never set this.
- Mining auth bypass: `MINING_OPEN=1` disables normal mining attestation/allowlist protections. Treat this as strictly dev-only; never enable on shared/public testnet infrastructure.
- The full node never self-mines. Mining must be driven externally (e.g., via Weave website) using `getMiningJob` / `submitShare` / `submitSolution`.
- Wallet/keystore operations are removed from the full node; use the standalone wallet CLI to build, sign, and submit transactions.
- Run RPC/mining endpoints behind TLS and authentication (bearer/capability tokens); avoid exposing them directly to the public internet.
- To rebuild cumulative work metadata after upgrading from pre-PoW builds: `cargo run --bin recompute_work -- ./data/chain`.

Operational controls

- Auto-update is enabled by default in the main binary path.
  - Disable on operator nodes with `LANTERN_UPDATE_DISABLED=1`.
  - Change polling with `LANTERN_UPDATE_INTERVAL=<seconds>` (default `300`).
  - Restart on successful update with `LANTERN_UPDATE_RESTART=1`.

HTTP API (staking/chain)

- `GET /weave/chain/head` → head/finalized hashes/heights and staking params
- `GET /weave/chain/validators` → validators, height, staking params (includes commission/jailed status)
- `GET /weave/chain/jailed` → list of jailed validators
- `GET /weave/chain/account?addr=...` → balances/nonce/stakes
- `GET /weave/chain/block?hash=...` or `?height=...` → block lookup
- `POST /weave/chain/tx` → queue a transaction (transfer/stake/unbond/slash/unjail), JSON body `{"tx":{...}}`
- `POST /weave/stake/bond|unbond` → staking helpers (same auth as chain endpoints)
- `POST /weave/chain/slash|unjail` → admin slash/unjail actions; require auth/capability

TLS mode (no PSK)

- Use real certificates to encrypt the transport instead of a shared PSK.
- Set environment variables and run as usual (generic listener on `PORT` or per-app ports):
  - `TLS_CERT=/etc/letsencrypt/live/lantern.5310s.com/fullchain.pem`
  - `TLS_KEY=/etc/letsencrypt/live/lantern.5310s.com/privkey.pem`
  - Example: `TLS_CERT=...</fullchain.pem> TLS_KEY=...</privkey.pem> PORT=8080 cargo run`
- Behavior:
  - If `TLS_CERT` and `TLS_KEY` are set, Lantern serves over TLS on the chosen port(s).
  - Commands and framing are unchanged (2-byte length prefix; plaintext commands inside TLS).
  - The included sample client (`src/bin/client.rs`) speaks Noise (PSK) only. A TLS client must implement the same framing and commands over TLS.

Simple TLS start (no PSK)

- Easiest way for production TLS with minimal flags:
  - `TLS_CERT=/path/to/fullchain.pem TLS_KEY=/path/to/privkey.pem lantern tls start`
  - Defaults: binds `:8080`, enables HTTP API, uses `./data` for persistence.
  - If no cert/key provided, Lantern automatically generates a self‑signed certificate under `./data/certs/` and uses it.
- Options:
  - `--port <p>` for single listener, or `--weave-port <p>` and/or `--worldstage-port <p>` for per-app ports.
  - `--http-port <p>` add an extra HTTP-capable TLS listener on a separate port (useful when per-app ports are non-HTTP).
  - `--data-dir <dir>` to change persistence dir.
  - `--no-http` to disable HTTP API (keeps framed TLS commands only).
  - `--token <str>` to require `Authorization: Bearer <str>` for HTTP GETs.
  - `--cert <path>` and `--key <path>` to pass cert/key via flags instead of env.
  - `--log-level`, `--max-addrs`, `--max-conns`, `--read-timeout`, `--write-timeout`, `--max-frame` for advanced tuning.

Weave integration (mTLS list + framed register)

- Run per-app TLS for Weave on 9001 without HTTP, and a separate HTTP-capable TLS port for list:
  - `lantern tls start --weave-port 9001 --no-http --http-port 9443 --data-dir ./data`
  - Caddy terminates HTTPS+mTLS and reverse_proxies to `https://127.0.0.1:9443` for `/weave/list` (and optionally `/weave/register` if using HTTP registration).
  - Weave registers directly to `lanternRegisterHost:9001` using framed `REGISTER` over TLS.

HTTP register/prune (Weave/World Stage)

- When running with TLS + HTTP enabled (fronted by Caddy with mTLS or a Bearer token), apps can register their reachable address and fetch the full peer list over HTTPS.
- Endpoints (authorization required: mTLS at Caddy or `Authorization: Bearer <token>`):
  - Register address: `POST /weave/register?addr=<host:port>` (aliases: `/dating/register`, or generic `POST /register?app=weave&addr=<host:port>`)
  - Remove address: `POST /weave/prune?addr=<host:port>` (aliases: `/dating/prune`, or generic `POST /prune?app=weave&addr=<host:port>`)
  - Remove all addresses for an app: `POST /weave/prune_all` (alias: `/dating/prune_all`, generic: `POST /prune?app=weave&all=true`)
  - Convenience (behind Caddy): `POST /weave/register?port=<p>` uses the client IP from `X-Forwarded-For` and the given port. Same for `/worldstage/...`.
  - Optional metadata: include `Content-Type: application/json` with a body describing the node (e.g., node ID and client version). Example:

    ```json
    {
      "node_id": 5310,
      "client_version": "0.0.1"
    }
    ```
  - Metadata is persisted and available via `GET /weave/nodes` (or `/worldstage/nodes`), which returns `{"count": <n>, "nodes": [{"addr": "host:port", "metadata": {...}}]}`.
  - Fetch list (JSON): `GET /weave/list` (aliases: `/dating/list`, generic: `GET /list?app=weave`)
  - Examples (Bearer token; mTLS users omit the header and present a client cert):
    - `curl -X POST -H "Authorization: Bearer $TOKEN" https://weave.example.com/weave/register?addr=1.2.3.4:9000`
    - `curl -X POST -H "Authorization: Bearer $TOKEN" https://weave.example.com/weave/register?port=9000`
    - `curl -H "Authorization: Bearer $TOKEN" https://weave.example.com/weave/list`
    - World Stage: replace `/weave/...` with `/worldstage/...` (alias: `/youtube/...`).
    - Generic single-port: `https://lantern.example.com/register?app=weave&addr=1.2.3.4:9000` and `GET /list?app=weave`.

HTTP limits and rate caps (env, defaults):
- `MAX_HTTP_BODY_BYTES` (524288) — maximum request body Lantern will buffer.
- `RPC_RATE_LIMIT_PER_MIN` (120) — `/rpc` requests per token/IP per minute.
- `MINING_JOB_RATE_PER_MIN` (30) — `/rpc` getMiningJob per token/IP per minute.
- `MINING_SHARE_RATE_PER_MIN` (60) — `/rpc` submitSolution/submitShare per token/IP per minute.

Notes:
- For `port=` registration, ensure your reverse proxy forwards the client IP (Caddy sets `X-Forwarded-For` by default).
- Addresses are still validated as `host:port` and stored per-app with capacity/limits enforced.

Quickstart

- With TLS (recommended for production):
  - `TLS_CERT=/path/to/fullchain.pem TLS_KEY=/path/to/privkey.pem lantern quickstart`
  - Binds `:8080` and uses TLS. No PSK needed. Keep the terminal open.
  - Interactive setup (default): run `lantern` and follow the prompts (TLS only by default).
  - No cert handy? The wizard will auto‑create a self‑signed cert in `./data/certs/` and continue.
- Without TLS (testing):
  - Generate a PSK (64-hex): `lantern keygen`
  - Run generic listener with fixed PSK: `NOISE_PSK=<64-hex> PORT=8080 DATA_DIR=./data lantern`
- Or run per-app listeners (two ports, separate PSKs):
  - `lantern --dating-port 9001 --dating-psk <64-hex> --youtube-port 9002 --youtube-psk <64-hex> --data-dir ./data`
- Test with the client:
  - HEALTH: `cargo run --bin client -- --psk <64-hex> --addr 127.0.0.1:8080 HEALTH`
  - VERSION: `cargo run --bin client -- --psk <64-hex> --addr 127.0.0.1:8080 VERSION`
  - LIST: `cargo run --bin client -- --psk <64-hex> --addr 127.0.0.1:8080 LIST --app youtube`
  - STATS: `cargo run --bin client -- --psk <64-hex> --addr 127.0.0.1:8080 STATS`

Docker

- Build: `docker build -t lantern:latest .`
- Run (generic listener):
  - `docker run --rm -p 8080:8080 -e NOISE_PSK=<64-hex> -e PORT=8080 -e DATA_DIR=/data -v $(pwd)/data:/data lantern:latest`
- Run (per-app listeners):
  - `docker run --rm -p 9001:9001 -p 9002:9002 -e DATING_PSK=<64-hex> -e DATING_PORT=9001 -e YOUTUBE_PSK=<64-hex> -e YOUTUBE_PORT=9002 -e DATA_DIR=/data -v $(pwd)/data:/data lantern:latest`
- Compose: edit `docker-compose.yml`, set PSKs and ports, then `docker compose up -d`.

systemd

- Install binary to `/usr/local/bin/lantern` and create a user:
  - `sudo useradd --system --no-create-home --shell /usr/sbin/nologin lantern || true`
  - `sudo mkdir -p /var/lib/lantern && sudo chown -R lantern:lantern /var/lib/lantern`
  - `sudo mkdir -p /etc/lantern && sudo cp packaging/systemd/lantern.env.example /etc/lantern/lantern.env`
  - `sudo cp packaging/systemd/lantern.service /etc/systemd/system/lantern.service`
- Edit `/etc/lantern/lantern.env` to set PSKs and ports.
- Enable and start:
  - `sudo systemctl daemon-reload`
  - `sudo systemctl enable --now lantern`
- Logs: `journalctl -u lantern -f`

Releases

- Build cross-platform release artifacts and checksums:
  - `bash scripts/release.sh`
  - Artifacts land in `dist/`, named like `lantern-vX.Y.Z-<target>.tar.gz` (or `.zip` for Windows), `LanternSetup.exe`, plus `SHA256SUMS` and `BINARY_HASHES`.
- Build Windows installer locally (maintainers):
  - `powershell -ExecutionPolicy Bypass -File .\scripts\build_windows_installer.ps1 -Version vX.Y.Z`
- Windows release asset URL format:
  - `https://github.com/5310S/lantern/releases/download/vX.Y.Z/LanternSetup.exe`
- `install.ps1` remains available as a fallback install path.
- Customize targets:
  - `TARGETS="x86_64-unknown-linux-gnu aarch64-unknown-linux-gnu" bash scripts/release.sh`
- Use `VERSION=...` to override auto-detected version.

Tagging and release notes

- Update `Cargo.toml` version if needed (current: 0.2.20).
- Generate artifacts and checksums: `bash scripts/release.sh`
- Create a Git tag: `git tag -a v0.1.0 -m "Lantern v0.1.0" && git push origin v0.1.0`
- Draft release notes using `CHANGELOG.md` contents.

Protocol (No HTTP, Noise PSK over TCP)

- Handshake: Noise_NNpsk0_25519_ChaChaPoly_BLAKE2s with a shared PSK.
- Framing: 2-byte big-endian length prefix for handshake and encrypted messages.
- After handshake, send human-readable line commands inside encrypted frames.

Commands

- Generic listener (PORT + NOISE_PSK):
  - `HEALTH` → `OK`
  - `LIST <weave|worldstage>` → returns addresses
  - `REGISTER <weave|worldstage> <host:port>` → `OK` on success
  - `PRUNE <weave|worldstage> <host:port>` → `OK REMOVED` or `ERR NOT_FOUND`
  - `QUIT` → `OK BYE`

- Scoped listeners (per-app ports): when using `DATING_PORT`/`YOUTUBE_PORT`, omit the app name:
  - `LIST`
  - `REGISTER <host:port>`
  - `PRUNE <host:port>`
  - `VERSION`, `STATS`, `HEALTH`, `QUIT`

Responses

- Unified status lines:
  - Success: `OK` (e.g., `OK`, `OK REMOVED`, `OK BYE`).
  - Errors: `ERR <CODE> <message>` (codes include `UNKNOWN_APP`, `LIST_FULL`, `PERSIST`, `SCOPE`, `INVALID_INPUT`, `USAGE`).
- LIST responses:
  - First frame: `OK LIST <count> CHUNKS <n>`.
  - Next `n` frames: newline‑delimited addresses. Concatenate and split by `\n`.
  - Other commands return a single `OK` or `ERR ...` line.

Notes

- Persistence is optional:
  - If `DATA_DIR` is set, addresses are loaded from `<DATA_DIR>/weave.txt` and `<DATA_DIR>/worldstage.txt` at startup and saved atomically on new registrations.
  - On first run after upgrade, Lantern will migrate old files (`dating.txt` → `weave.txt`, `youtube.txt` → `worldstage.txt`) automatically if present.
  - If `DATA_DIR` is not set, state is in-memory only (restart clears lists).
- Security: all commands are encrypted and authenticated via Noise with PSK. No certificates, no URLs.

Per‑app listeners (optional)

- Run separate listeners with distinct keys/ports:
  - Weave: `DATING_PORT` + `DATING_PSK` (or `WEAVE_PORT`/`WEAVE_PSK`)
  - World Stage: `YOUTUBE_PORT` + `YOUTUBE_PSK` (or `WORLD_STAGE_PORT`/`WORLD_STAGE_PSK`)
- If neither is set, Lantern falls back to single listener using `PORT` + `NOISE_PSK`.

Logging

- Configure verbosity with `LOG_LEVEL` (default: `info`).
- Supported values: `error`, `warn`, `info`, `debug`.

Limits and timeouts

- Max encrypted frame size: 16KiB.
- Max addresses per app: 1000.
- Max concurrent connections: 100.
- Read/write timeout: 15s each.

Client outline (pseudocode)

- Build initiator with same suite and PSK.
- Send first handshake message (length-prefixed), receive server’s handshake message.
- Derive transport state, then for each command:
  - Encrypt plaintext line (e.g., `LIST youtube\n`), write as length-prefixed frame.
  - Read length-prefixed frame, decrypt to plaintext response lines.

HTTP client outline (apps behind Caddy, recommended):
- Register address over HTTPS (mTLS or Bearer token):
  - `POST /weave/register?addr=<host:port>` or `POST /weave/register?port=<p>`
  - On success, response is `{ "status": "ok" }`.
- Download list:
  - `GET /weave/list` (JSON `{ "count": N, "addrs": [ ... ] }`).

Web bundle mirror (Weave site)
- Keep the Weave web bundle in a separate repo/release. Use `scripts/fetch_weave_assets.sh` to download a signed tarball into `data_dir/assets`, set `ENABLE_ASSET_MIRROR=1`, and serve it via TLS HTTP. See docs/weave-assets.md.

Sample CLI client

- A reference client is included: `src/bin/client.rs`.
- Usage examples:
  - `cargo run --bin client -- --psk <64-hex> --addr <host:port> HEALTH`
  - `cargo run --bin client -- --psk <64-hex> --addr <host:port> LIST --app youtube`
  - `cargo run --bin client -- --psk <64-hex> --addr <host:port> REGISTER --app youtube 1.2.3.4:9000`
  - `cargo run --bin client -- --psk <64-hex> --addr <host:port> PRUNE --app youtube 1.2.3.4:9000`
  - For scoped listeners (e.g., only dating), `--app` can be omitted for LIST/REGISTER/PRUNE.

Configuration summary

- Flags (preferred):
  - `--port`, `--noise-psk`, `--data-dir`, `--log-level`
  - Per-app: `--dating-port`, `--dating-psk`, `--youtube-port`, `--youtube-psk`
  - Limits: `--max-frame`, `--max-addrs`, `--max-conns`, `--read-timeout`, `--write-timeout`, `--noise-overhead`
  - Node: `lantern node init/run` + helpers (`set-payout`, `set-commission`, `params`, `validators`, `inspect-store`, `build-tx`, `bond`, `unbond`, `withdraw`)
- Env fallbacks:
  - `PORT`, `NOISE_PSK`, `DATA_DIR`, `LOG_LEVEL`
  - `DATING_PORT`, `DATING_PSK`, `YOUTUBE_PORT`, `YOUTUBE_PSK`
  - `MAX_FRAME_LEN`, `MAX_ADDRS`, `MAX_CONNS`, `READ_TIMEOUT`, `WRITE_TIMEOUT`, `NOISE_OVERHEAD`


Restricting Access (mTLS)

- To allow only Weave/World Stage apps to fetch lists, enable client certificate auth at Caddy (mTLS):
  - Run the interactive wizard, answer Yes to "Restrict access using mTLS".
  - Lantern will generate a client CA (if missing), produce a Caddyfile with client_auth, and can apply it to /etc/caddy/Caddyfile.
  - Issue an app client cert: `lantern issue-client --cn worldstage --out /etc/caddy/clients --ca-dir /etc/caddy/clients`
  - The app presents the client cert/key on HTTPS; Caddy enforces mTLS and proxies to Lantern.
  - See docs/MTLS.md for details and app snippets.
